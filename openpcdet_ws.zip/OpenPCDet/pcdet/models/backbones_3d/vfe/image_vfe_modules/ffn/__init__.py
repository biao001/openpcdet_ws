from .depth_ffn import DepthFFN

__all__ = {
    'DepthFFN': DepthFFN
}
