from .point_head_box import PointHeadBox
from .point_head_simple import PointHeadSimple
from .my_dense_head import MyDenseHead


__all__ = {
    'PointHeadSimple': PointHeadSimple,
    'PointHeadBox': PointHeadBox,
    'MyDenseHead': MyDenseHead,
}
