from .detector3d_template import Detector3DTemplate


class MyPointRCNN(Detector3DTemplate):
    # 调用父类的初始化方法，并通过 build_networks 方法构建网络模块列表保存在 self.module_list 中
    def __init__(self, model_cfg, num_class, dataset):
        super().__init__(model_cfg=model_cfg, num_class=num_class, dataset=dataset)
        self.module_list = self.build_networks()

    # 遍历 self.module_list 中的每个模块，对输入的 batch_dict 进行处理
    def forward(self, batch_dict):
        for cur_module in self.module_list:
            batch_dict = cur_module(batch_dict)

        if self.training:
            loss, tb_dict, disp_dict = self.get_training_loss()

            ret_dict = {
                'loss': loss
            }
            return ret_dict, tb_dict, disp_dict
        else:
            pred_dicts, recall_dicts = self.post_processing(batch_dict)
            return pred_dicts, recall_dicts

    # get_training_loss 方法：用于计算训练损失。它首先获取 point_head 的损失和相关的 tb_dict，然后获取 roi_head 的损失和 tb_dict，将两者相加得到总损失
    def get_training_loss(self):
        disp_dict = {}
        loss_point, tb_dict = self.point_head.get_loss()
        loss_rcnn, tb_dict = self.roi_head.get_loss(tb_dict)

        loss = loss_point + loss_rcnn
        return loss, tb_dict, disp_dict
