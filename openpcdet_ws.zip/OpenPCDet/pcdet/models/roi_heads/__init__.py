from .pointrcnn_head import PointRCNNHead
from .my_roi_head import MyRoiHead


__all__ = {
    'MyRoiHead': MyRoiHead,
    'PointRCNNHead': PointRCNNHead,
}
