import numpy as np
import lib.python.nearest_neighbors as nearest_neighbors
import time
import torch
from torch_points_kernels import knn
from knn_cuda import KNN
import torch_points_kernels.points_cuda

K = 16

d_in = 3
coords = 1000 * torch.randn(1, 2 ** 14, d_in)

# gpu1
start = time.time()
neigh_idx = nearest_neighbors.knn_batch(coords, coords, K, omp=True)
print('gpu1:', time.time() - start)

# # gpu2 显存拉爆
# t00 = time.time()
# knn2 = KNN(k=K, transpose_mode=True)
# dist, indx = knn2(coords.cuda(), coords.cuda())
# t11 = time.time()
# t22 = t11 - t00
# print('gpu2:', t22)


# cpu
t0 = time.time()
knn_output = knn(coords.cpu().contiguous(), coords.cpu().contiguous(), K)
t1 = time.time()
t2 = t1 - t0
print('cpu', t2)

print('gpu1:', neigh_idx[0][0])
# print('gpu2:', indx[0])
print('cpu:', knn_output[0][0][0])

'''
批次越多，gpu越快
(16, 2 ** 15, 3)
gpu1: 0.16306638717651367
cpu 1.088576316833496
gpu1: [    0 27142 20730 29119  1555 11376 20570 15894 29069 22745 13377 16272
  6631 32717  1970 11190]
cpu: tensor([    0, 27142, 20730, 29119,  1555, 11376, 20570, 15894, 29069, 22745,
        13377, 16272,  6631, 32717,  1970, 11190])
'''

'''
(1, 2 ** 20, 3)
gpu1: 3.8958332538604736
cpu 3.1585285663604736
gpu1: [      0  502663  688783  821445  943517 1042541  141071  205217  835092
  755490  108421  216147  689339  765608  985292    5582]
cpu: tensor([      0,  502663,  688783,  821445,  943517, 1042541,  141071,  205217,
         835092,  755490,  108421,  216147,  689339,  765608,  985292,    5582])
'''
