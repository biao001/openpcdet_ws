import torch
import torch.nn.functional as F
import time


def knn(support, query, k):
    """
    Args:
        support (torch.Tensor): 支持集张量，形状为[N1, D]，N1是支持集的点数，D是特征维度。
        query (torch.Tensor): 查询集张量，形状为[N2, D]，N2是查询集的点数。
        k (int): 需要找到的最近邻的数量。

    Returns:
        Tuple[torch.Tensor, torch.Tensor]: 第一个张量形状为[N2, k]，包含每个查询点的k个最近邻在支持集中的索引；
                                          第二个张量形状也为[N2, k]，包含对应的距离。
    """
    t1 = time.time()
    # 计算查询集与支持集间的所有点对距离
    dist_matrix = torch.cdist(query, support, p=2)  # 使用欧氏距离
    t2 = time.time()
    print('gpu1:', t2 - t1)
    # 对每个查询点，找出距离最近的k个点的索引
    _, indices = torch.topk(dist_matrix, k=k, dim=1, largest=False)
    t3 = time.time()
    print('gpu2:', t3 - t2)
    # 获取对应的k个最近邻的距离
    distances = torch.gather(dist_matrix, dim=1, index=indices)
    t4 = time.time()
    print('gpu3:', t4 - t3)
    return indices, distances


K = 16
d_in = 3
coords = 1000 * torch.randn(2 ** 14, d_in)
t00 = time.time()
dist, indx = knn(coords, coords, K)
t11 = time.time()
t22 = t11 - t00
# print('gpu2:', t22)
